<?php
$conexion = new mysqli("localhost", "root", "", "citasmedicas");
if($conexion){

}
else{
    echo "Conexion no exitosa";
}
?>

