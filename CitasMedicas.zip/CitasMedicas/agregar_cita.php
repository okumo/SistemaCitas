<html>
    <head>
        <title>AGREGAR UNA CITA</title>
        <?php
        try{
	$conexion = new PDO('mysql:host=localhost;dbname=citasmedicas','root','');
}catch(PDOException $e){
	echo "Error: ". $e->getMessage();
}
//SELECT PARA MEDICOS
$medicos = $conexion -> prepare("SELECT * FROM medicos");
$medicos ->execute();
$medicos = $medicos ->fetchAll();
//SELECT PARA CONSULTORIOS
//SELECT PARA PACIENTES
$usuario = $conexion -> prepare("SELECT * FROM usuarios where id not in (1)");
$usuario ->execute();
$usuario = $usuario ->fetchAll();
?>
    </head>
    <body>
    <center>
        <h2>
           NUEVA CITA
        </h2>
        <form action="operacion_guardar_cita.php" method="post">
						
						<label>Fecha:</label>
                                                <input type="date" name="fecha" placeholder="Fecha:" required/><p>
                        <label>Hora:</label>
           <input type="time" name="hora" value="11:45" max="20:30" min="08:00" step="60" required><p>
            <label>Paciente:</label>
            <select name="usuario" class="mayusculas" required> 
	            <?php foreach ($usuario as $sql1): ?>
			<?php echo "<option value='". $sql1['nombres']. "'>". $sql1['nombres']." ".$sql1['apellidos']."</option>"; ?>
				<?php endforeach; ?>
            </select><p>
                        <label>Medicos:</label>
                        <select name="medico" class="mayusculas" required> 
	                        <?php foreach ($medicos as $Sql): ?>
<?php echo "<option value='". $Sql['mednombres']. "'>". $Sql['mednombres']." ". $Sql['medapellidos']. "</option>"; ?>
		<?php endforeach; ?>
                        </select><p>
                        
                        <label REQUIRED>Estado:</label>
                        <select name="estado">
                        	<option value="asignado">Asignado</option>
                        	<option value="atendido">Atendido</option>                    	
                        </select><p>
               <label>Observaciones:</label><p>
                        <textarea placeholder="Observacion:" name="observaciones"></textarea><p>
						<input type="submit" name="enviar" value="Agregar Cita">
					</form>
        
    </center>
    
    </body>
</html>

