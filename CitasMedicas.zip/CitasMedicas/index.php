<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">    </head>
    <body>
    <center>
        <h1>Bienvenido</h1><p>
        <form action="proceso.php" method="POST">
            <input type="text" name="usuario" value="" placeholder="Usuario..."/><p>
            <input type="password" name="contraseña" value="" placeholder="Contraseña..."/><p>
                <input type="submit" name="Ingresar" value="Ingresar"/> 
        </form>
        <a href="agregar_usuario.php"><input type="button" value="Registrarse"></a>
    </center>
        
    </body>
</html>
